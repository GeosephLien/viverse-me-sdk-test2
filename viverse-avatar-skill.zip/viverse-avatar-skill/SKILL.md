---
name: viverse-avatar-skill
description: "Integrate the VIVERSE Avatar SDK into websites, games, and Three.js experiences. Use when implementing SDK Happy Path, Host Sign In, avatar selection events, panel customization, signed avatar URL handling, VRMA animations, or the Avatar Controller."
argument-hint: "Describe the VIVERSE Avatar integration you want to build or debug"
---

# VIVERSE Avatar SDK

Use this skill to build or troubleshoot a third-party integration with the public VIVERSE Avatar SDK.

## Source Of Truth

The current public documentation is [VIVERSE Avatar SDK Guide](https://viverse-me.com/sdk/guide.html). Check it when network access is available, especially before relying on option names, defaults, payload fields, or security requirements. The bundled references are an offline snapshot and may be older than the hosted guide.

## Integration Workflow

1. Ask whether the host needs anonymous Happy Path, Host Sign In, the optional VIVERSE Avatar Library, or a combination.
2. Confirm the host has an SDK Integration ID and that its exact `window.location.origin` is listed under Allowed Websites.
3. Use `https://viverse-me.com/sdk.js` with `mode: 'sdk-happy-path'`. Never copy a real integration ID into generated examples; use `partner_...` unless the user supplies one.
4. For a new Three.js game without existing physics, default to the bundled Avatar Controller with `physics: 'builtin'`; do not hand-roll movement, orbit, zoom, jump, joystick, or VRMA state transitions.
5. Load the VRM with `GLTFLoader` + `VRMLoaderPlugin`, clean it with `VRMUtils`, and pass both the VRM and `avatar.animations` to `controller.setAvatar()`.
6. Apply `avatar.controlsHint` and later `viverse-me:controls-changed` payloads through `setEnableAnimation()`, `setEnableControl()`, and `setControllerSize()`.
7. Pause rendering and hide controller UI on `viverse-me:open`; resume and restore eligible controls on `viverse-me:close`. Show touch controls only after an avatar is loaded and the SDK panel is closed.
8. Use `vrmUrl` and `thumbnailUrl` only for immediate preview. Persist stable references such as `partnerId`, `tenantId`, `key`, and a stable host subject instead of signed URLs.
9. Validate authorization failure, expired signed URLs, cleared browser storage, iframe CSP, resize, WebGL lifecycle, avatar replacement/disposal, and mobile controls.

## Three.js Completion Standard

When asked to build a complete Three.js avatar game or experience, do not stop at the minimal selection listener below. The result is complete only when it includes:

- The documented shared import map for Three.js, `@pixiv/three-vrm`, and `@pixiv/three-vrm-animation`.
- A host-owned scene, renderer, lights, resize handling, `GLTFLoader`, and one animation loop with a clamped delta.
- The SDK-owned Avatar Controller using `window.ViverseMeSDK.avatarControllerUrl` and `window.ViverseMeSDK.animations`.
- Happy Path selection, VRM replacement and disposal, payload animation overrides, control-hint synchronization, SDK open/close pause behavior, and touch-control visibility.
- A loading state and an error path that leave the previous avatar usable when a replacement fails.

Use Tier B (`physics: 'none'`) only when the host already owns physics, collision, camera, movement, or control UI. In Tier B, keep Happy Path selection and VRMA loading, but do not let the controller own world movement or vertical position.

## Selection-Only Integration

This is appropriate when an existing host scene already owns VRM loading, animation, controls, lifecycle, and disposal. It is not a complete Three.js game setup.

```html
<div id="viverse-me-button-slot"></div>
<script
  src="https://viverse-me.com/sdk.js"
  data-ac3-mode="sdk-happy-path"
  data-ac3-target="#viverse-me-button-slot"
  data-ac3-partner-id="partner_..."
  data-ac3-label="Start"
  async
></script>
<script>
  window.addEventListener('viverse-me:avatar-selected', (event) => {
    const avatar = event.detail.avatar;
    hostScene.loadAvatar(avatar.vrmUrl, {
      animations: avatar.animations,
      controlsHint: avatar.controlsHint
    });
    partnerApi.saveSelectedAvatarReference({
      partnerId: avatar.partnerId,
      userId: avatar.userId,
      tenantId: avatar.tenantId,
      key: avatar.key
    });
  });
</script>
```

## Security Boundaries

- Do not expose `PARTNER_API_TOKEN`, admin tokens, or backend secrets in browser code.
- Do not call account, draft, upload, claim, or `/api/ac3/download-url` routes directly from the third-party host page. The embedded SDK owns those flows.
- Allow `https://viverse-me.com` in the host's `frame-src` CSP.
- Treat signed asset URLs as expiring preview transport.
- Verify host identities with the partner's own authentication system before calling `openWithHostSignIn()`.
- Do not assume anonymous avatars merge into a Host Sign In account; those storage identities are independent.

## Choose References

- For initialization, authorization, Host Sign In, events, payloads, panel options, and backend restoration, read [SDK integration reference](./references/sdk-integration.md).
- For VRMA clips, integration tiers, Three.js peer dependencies, physics, camera, movement, and jump behavior, read [Avatar Controller reference](./references/avatar-controller.md).
